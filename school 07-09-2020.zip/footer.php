                <footer class="footer text-right">
                    <h6>2020 - 2021 © Revolutionary-Technologies. ツ</h6>
                </footer>
                
                <?php 
                // hasaccess();
                 ?>



                