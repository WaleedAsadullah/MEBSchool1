 <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!-- User -->
                    <div class="user-box">
                        <div class="user-img">
                            <img src="assets/images/users/logo.jpg" alt="M.E.B School" title="M.E.B School"  class="img-circle img-thumbnail img-responsive">
                            <div class="user-status offline"><i class="zmdi zmdi-dot-circle"></i></div>
                        </div>
                        <h5><a href="#"> <?php echo $_SESSION['name']; ?></a> </h5>
                        <ul class="list-inline">
                            <li>
                                <a href="Parents-mod-profile.php">
                                    <i class="zmdi zmdi-settings"></i>
                                </a>
                            </li>

                            <li>
                                <a href="logout.php" class="text-custom">
                                    <i class="zmdi zmdi-power"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- End User -->

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                            <li class="text-muted menu-title">Navigation</li>

                            

                            <li>
                                <a href="Parents-mod-child-progress-reports.php" class="waves-effect"><i class="zmdi zmdi-chart"></i> <span> Child Progress Report </span> </a>
                            </li>

                            <li class="active">
                                <a href="Parents-mod-fees-reports.php" class="waves-effect "><i class="zmdi zmdi-reader"></i> <span>  Fee Reports </span> </a>
                            </li>

                             <li>
                                <a href="Parents-mod-announcement.php" class="waves-effect"><i class="fa fa-comment"></i> <span> Announcement
                                 </span> </a>
                            </li>

                            <li>
                                <a href="Parents-mod-family-feature.php" class="waves-effect"><i class="fa fa-wpforms"></i> <span> Family Feature </span> </a>
                            </li>
                            <li>
                                <a href="Parents-mod-my-child-detail.php" class="waves-effect"><i class="fa fa-address-card"></i> <span> My Child Details  </span> </a>
                            </li>
                            <li>
                                <a href="Parents-mod-feedback.php" class="waves-effect"><i class="fa fa-wpforms"></i> <span>Feedback Form </span> </a>
                            </li>

                            <li>
                                <a href="Parents-mod-inquiry.php" class="waves-effect"><i class="fa fa-user-secret"></i> <span> Inquiry </span> </a>
                            </li>


                        </ul>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
                    
                    <!-- Sidebar -->
 