                <footer class="footer text-right">
                    <h6>2016 - 2017 © Adminto.</h6>
                </footer>